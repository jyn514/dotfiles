(ns flower.page.source)

(defn resolve-template [page]
  (let [template (:template page)]
    (cond
      (and (nil? template) (contains? page :template))
      {:kind :disabled
       :template nil}

      (nil? template)
      {:kind :default
       :template "templates/default.pet"}

      (string? template)
      {:kind :explicit
       :template (str "templates/" template)}

      :else
      {:kind :invalid
       :template nil
       :value template})))
